# Type

This directory contains type definitions. Each type is registered into the TypeRegistry for
use throughout the Schema. 

